GPU: NVIDIA H200 (139.8 GB, sm_90) | torch 2.5.1+cu121 | CUDA 12.1 | triton 3.1.0 | vllm None | transformers 4.56.1

Time to first token (s, lower is better)
| prompt | batch | hf | vllm | custom | custom vs hf | custom vs vllm |
|---|---|---|---|---|---|---|
| 128 | 1 | 0.025 | 0.013 | 0.015 | 1.68x | 0.90x |
| 128 | 8 | 0.064 | 0.053 | 0.049 | 1.31x | 1.09x |
| 128 | 32 | 0.226 | 0.181 | 0.183 | 1.24x | 0.99x |
| 1024 | 1 | 0.064 | 0.046 | 0.050 | 1.30x | 0.93x |
| 1024 | 8 | 0.464 | 0.350 | 0.381 | 1.22x | 0.92x |
| 1024 | 32 | 1.876 | 1.412 | 1.512 | 1.24x | 0.93x |

Decode throughput (tokens/s across the batch, higher is better)
| prompt | batch | hf | vllm | custom | custom vs hf | custom vs vllm |
|---|---|---|---|---|---|---|
| 128 | 1 | 43.5 | 112.3 | 113.8 | 2.62x | 1.01x |
| 128 | 8 | 339.3 | 878.7 | 883.6 | 2.60x | 1.01x |
| 128 | 32 | 1354.9 | 3288.3 | 3033.7 | 2.24x | 0.92x |
| 1024 | 1 | 43.6 | 112.0 | 113.0 | 2.59x | 1.01x |
| 1024 | 8 | 336.8 | 848.1 | 867.1 | 2.57x | 1.02x |
| 1024 | 32 | 1106.0 | 2969.9 | 2622.1 | 2.37x | 0.88x |

End-to-end throughput (tokens/s, higher is better)
| prompt | batch | hf | vllm | custom | custom vs hf | custom vs vllm |
|---|---|---|---|---|---|---|
| 128 | 1 | 43.5 | 111.8 | 113.2 | 2.60x | 1.01x |
| 128 | 8 | 334.9 | 846.5 | 854.2 | 2.55x | 1.01x |
| 128 | 32 | 1269.7 | 2891.7 | 2690.3 | 2.12x | 0.93x |
| 1024 | 1 | 43.0 | 108.5 | 109.1 | 2.54x | 1.01x |
| 1024 | 8 | 294.2 | 661.5 | 659.5 | 2.24x | 1.00x |
| 1024 | 32 | 738.0 | 1473.0 | 1337.8 | 1.81x | 0.91x |

(Speedup columns: >1 means the custom engine is faster; for time-to-first-token they are other/custom.)

Greedy token agreement with Hugging Face (fraction of requests with identical output)
| prompt | batch | vllm | custom |
|---|---|---|---|
| 128 | 1 | 1.00 | 1.00 |
| 128 | 8 | 1.00 | 1.00 |
| 128 | 32 | 1.00 | 1.00 |
| 1024 | 1 | 1.00 | 1.00 |
| 1024 | 8 | 1.00 | 1.00 |
| 1024 | 32 | 1.00 | 1.00 |