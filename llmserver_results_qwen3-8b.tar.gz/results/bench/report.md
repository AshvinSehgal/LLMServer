GPU: NVIDIA H200 (139.8 GB, sm_90) | torch 2.5.1+cu121 | CUDA 12.1 | triton 3.1.0 | vllm None | transformers 4.56.1

Time to first token (s, lower is better)
| prompt | batch | hf | vllm | custom | custom vs hf | custom vs vllm |
|---|---|---|---|---|---|---|
| 128 | 1 | 0.022 | 0.013 | 0.013 | 1.66x | 0.96x |
| 128 | 8 | 0.038 | 0.034 | 0.026 | 1.48x | 1.33x |
| 128 | 32 | 0.133 | 0.101 | 0.099 | 1.35x | 1.02x |
| 1024 | 1 | 0.039 | 0.024 | 0.028 | 1.42x | 0.86x |
| 1024 | 8 | 0.269 | 0.188 | 0.202 | 1.33x | 0.93x |
| 1024 | 32 | 1.076 | 0.766 | 0.810 | 1.33x | 0.95x |

Decode throughput (tokens/s across the batch, higher is better)
| prompt | batch | hf | vllm | custom | custom vs hf | custom vs vllm |
|---|---|---|---|---|---|---|
| 128 | 1 | 49.9 | 179.2 | 185.1 | 3.71x | 1.03x |
| 128 | 8 | 391.0 | 1348.7 | 1436.8 | 3.67x | 1.07x |
| 128 | 32 | 1545.1 | 5009.6 | 4712.6 | 3.05x | 0.94x |
| 1024 | 1 | 50.3 | 177.6 | 183.1 | 3.64x | 1.03x |
| 1024 | 8 | 390.8 | 1293.0 | 1376.4 | 3.52x | 1.06x |
| 1024 | 32 | 1370.3 | 4409.6 | 3876.9 | 2.83x | 0.88x |

End-to-end throughput (tokens/s, higher is better)
| prompt | batch | hf | vllm | custom | custom vs hf | custom vs vllm |
|---|---|---|---|---|---|---|
| 128 | 1 | 49.8 | 177.4 | 183.1 | 3.68x | 1.03x |
| 128 | 8 | 388.4 | 1300.0 | 1397.0 | 3.60x | 1.07x |
| 128 | 32 | 1482.1 | 4491.9 | 4260.3 | 2.87x | 0.95x |
| 1024 | 1 | 49.9 | 173.2 | 177.4 | 3.56x | 1.02x |
| 1024 | 8 | 356.9 | 1051.8 | 1089.3 | 3.05x | 1.04x |
| 1024 | 32 | 1013.3 | 2427.3 | 2203.9 | 2.17x | 0.91x |

(Speedup columns: >1 means the custom engine is faster; for time-to-first-token they are other/custom.)

Greedy token agreement with Hugging Face (fraction of requests with identical output)
| prompt | batch | vllm | custom |
|---|---|---|---|
| 128 | 1 | 1.00 | 1.00 |
| 128 | 8 | 1.00 | 1.00 |
| 128 | 32 | 1.00 | 1.00 |
| 1024 | 1 | 1.00 | 1.00 |
| 1024 | 8 | 1.00 | 1.00 |
| 1024 | 32 | 1.00 | 1.00 |